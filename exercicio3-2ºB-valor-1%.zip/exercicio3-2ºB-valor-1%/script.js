let saldo = document.querySelector("#saldo");

let btSomar = document.querySelector("#btSomar");
let h3Resultado = document.querySelector("#h3Resultado");

function somarNumeros(){

    let num1 = Number(saldo.value); 
    

    h3Resultado.textContent = "Soldo com reajuste: " + (num1 + (num1 * (1/100)));
}

btSomar.onclick = function(){
    somarNumeros();
}