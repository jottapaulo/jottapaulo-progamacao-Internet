let btCalcular = document.querySelector("#btCalcular");
let raio = document.querySelector("#raio");
let h3Resultado = document.querySelector("#h3Resultado");

function calcularArea() {
    let pi = 3.14;
    let raio1 = parseFloat(raio.value);

    if (isNaN(raio1) || raio1 <= 0) {
        h3Resultado.textContent = "Informe um raio válido (maior que 0).";
        return;
    }

    let area = pi * raio1 * raio1;
    h3Resultado.textContent = "Área da pizza: " + area.toFixed(2) + " cm²";
}

btCalcular.onclick = function () {
    calcularArea(); // corrigido o nome da função
};
