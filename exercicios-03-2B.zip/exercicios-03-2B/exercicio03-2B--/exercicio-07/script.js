let btCalcular = document.querySelector("#btCalcular");

let inputdia = document.querySelector("#inputdia");
let inputMes = document.querySelector("#inputMes");

let h3Resultado = document.querySelector("#h3Resultado");

function CalcularDias() {

let dias  = Number (inputdia.value);
let mes  = Number (inputMes.value);


h3Resultado.textContent = "Se Passaram   " + (( (mes -1 ) * 30) + dias) + " Dias desde o inicio do ano";


}

btCalcular.onclick = function(){
    CalcularDias();
}