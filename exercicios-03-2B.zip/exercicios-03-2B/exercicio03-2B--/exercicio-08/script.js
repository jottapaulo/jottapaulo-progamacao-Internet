let btCalcular = document.querySelector("#btCalcular");

let inputPequeno = document.querySelector("#inputPequeno");
let inputMedio = document.querySelector("#inputMedio");
let inputGrande = document.querySelector("#inputGrande");

let h3Resultado = document.querySelector("#h3Resultado");

function CalcularDias() {

let NumPequeno  = Number (inputPequeno.value);
let NumMedio  = Number (inputMedio.value);
let NumGrande  = Number (inputGrande.value);


h3Resultado.textContent = "Valor Arrecadado R$ " + ((NumPequeno * 10) + (NumMedio * 12) + (NumGrande * 15)) + " Reais";


}

btCalcular.onclick = function(){
    CalcularDias();
}