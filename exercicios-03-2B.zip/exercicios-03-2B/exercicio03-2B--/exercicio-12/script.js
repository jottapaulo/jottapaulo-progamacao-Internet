let btCalcular = document.querySelector("#btCalcular");

let inputNumero = document.querySelector("#inputNumero");


let h3Resultado = document.querySelector("#h3Resultado ");



function Calcular() {

let NumNumero = Number (inputNumero.value);
let centena = Math.floor(NumNumero / 100);
let dezena = Math.floor((NumNumero % 100) / 10);
let unidade = NumNumero % 10;


h3Resultado.textContent = "A centena é " + centena + " a dezena é " + dezena + " a unidade é " + unidade;



}

btCalcular.onclick = function(){
    Calcular();
}