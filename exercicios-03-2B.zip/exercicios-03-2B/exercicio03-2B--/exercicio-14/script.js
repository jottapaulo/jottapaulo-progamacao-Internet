let btCalcular = document.querySelector("#btCalcular");
let valorConta = document.querySelector("#valorConta");
let resultado = document.querySelector("#resultado");

btCalcular.onclick = function() {
    let total = parseFloat(valorConta.value);

    if (isNaN(total) || total <= 0) {
        resultado.textContent = "Informe um valor válido.";
        return;
    }

    let parteInteira = Math.floor(total / 3); 
    let carlos = parteInteira;
    let andre = parteInteira;
    let felipe = (total - carlos - andre).toFixed(2); 

    resultado.textContent = 
        "Carlos: R$" + carlos.toFixed(2) + " | " +
        "André: R$" + andre.toFixed(2) + " | " +
        "Felipe: R$" + felipe;
};
