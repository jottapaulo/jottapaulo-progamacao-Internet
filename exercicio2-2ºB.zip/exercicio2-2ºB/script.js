let valorkg = document.querySelector("#valorkg");
let quantidadekg = document.querySelector("#quantidadekg");
let btValor = document.querySelector("#btValor");
let h3Resultado = document.querySelector("#h3Resultado");

function calcularvalor(){

    let num1 = Number(valorkg.value);
    let num2 = Number(quantidadekg.value);

    h3Resultado.textContent = "Valor total " + (num1 * num2);
}

btValor.onclick = function(){
    calcularvalor();
}