let btCalcular = document.querySelector("#btCalcular");

let inputQuilos = document.querySelector("#inputQuilos");

let h3Resultado = document.querySelector("#h3Resultado");

function CalcularPrecoPrato() {

let quantQuilo  = (inputQuilos.value);
let precoQuilo = 12;

h3Resultado.textContent = "Total a pagar pelo prato de comida:  " +  "R$ " + (quantQuilo * precoQuilo ).toFixed(2) ;


}

btCalcular.onclick = function(){
    CalcularPrecoPrato();
}