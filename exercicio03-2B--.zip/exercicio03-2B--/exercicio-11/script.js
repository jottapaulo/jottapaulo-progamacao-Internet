let btCalcular = document.querySelector("#btCalcular");

let inputSalario = document.querySelector("#inputSalario");


let h3ResultadoInicial = document.querySelector("#h3ResultadoInicial");
let h3Resultado15 = document.querySelector("#h3Resultado15");
let h3ResultadoFinal = document.querySelector("#h3ResultadoFinal");

function CalcularDias() {

let NumSalario = Number (inputSalario.value);



h3ResultadoInicial.textContent = "Salario Inicial: " + (NumSalario + );
h3Resultado15.textContent = "Salario com 15%:  " + (NumDias / 15/100 ) ;
h3ResultadoFinal.textContent = "Salario: " + (NumDias) ;


}

btCalcular.onclick = function(){
    CalcularDias();
}