let btCalcular = document.querySelector("#btCalcular");

let inputX = document.querySelector("#inputX");
let inputY = document.querySelector("#inputY");


let h3Resultado = document.querySelector("#h3Resultado");

function CalcularX() {

let NumX  = Number (inputX.value);
let NumY  = Number (inputY.value);



h3Resultado.textContent = "Distancia " + ((NumPequeno * 10) + (NumMedio * 12) + (NumGrande * 15)) + " Reais";


}

btCalcular.onclick = function(){
    CalcularX();
}