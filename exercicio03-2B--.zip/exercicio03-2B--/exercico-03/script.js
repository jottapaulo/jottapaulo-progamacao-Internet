let btSomar = document.querySelector("#btSomar");

let input1 = document.querySelector("#input1");
let input2 = document.querySelector("#input2");



let h3Resultadoinput1 = document.querySelector("#h3Resultadoinput1");
let h3Resultadoinput = document.querySelector("#h3Resultadoinput2");



function exibirOperacaoes(){

    let num1 = Number(input1.value); 
    let num2 = Number(input2.value); 
    

    h3Resultadoinput1.textContent = " Total Arrecadado Dia : R$ " + ((num1 * 0.12) + (num2 * 1.50));
    h3Resultadoinput2.textContent = " Devem ser Guardados na poupanca (10%) : R$ " + ((num1 * 0.12) + (num2 * 1.50)) * 10/100;
   
   
   
}

btSomar.onclick = function(){
    exibirOperacaoes();
}