let btSomar = document.querySelector("#btSomar");

let input1 = document.querySelector("#input1");
let input2 = document.querySelector("#input2");



let h3Resultadoinput1 = document.querySelector("#h3Resultadoinput1");


function exibirOperacaoes(){

    let num1 = Number(input1.value); 
    let num2 = Number(input2.value); 
    

    h3Resultadoinput1.textContent = " São Necessarias : " + ((num1 * 0.12) + (num2 * 1.50));
   
   
   
}

btSomar.onclick = function(){
    exibirOperacaoes();
}