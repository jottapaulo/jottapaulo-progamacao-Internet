let campo1 = document.querySelector("#campo1");
let campo2 = document.querySelector("#campo2");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function somarNumeros(){

    let num1 = Number(campo1.value);
    let num2 = Number(campo2.value);

    resultado.textContent = "resultado "+(num1 + num2);
}

btCalcular.onclick = function() {
    somarNumeros();
}