let inputvalor1 = document.querySelector("#inputvalor1");
let inputvalor2 = document.querySelector("#inputvalor2");
let btSubtrair = document.querySelector("#btSubtrair");
let h3Resultado = document.querySelector("#h3Resultado");

function calculartroco(){

    let num1 = Number(inputvalor1.value);
    let num2 = Number(inputvalor2.value);

    h3Resultado.textContent = (num1 - num2);
}

btSubtrair.onclick = function(){
    calculartroco();
}