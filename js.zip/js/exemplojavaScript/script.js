let titulo = document.querySelector("#titulo");
let campotexto = document.querySelector("#campotexto");
let btTrocarTexto = document.querySelector("#btTrocarTexto");