let titulo = document.querySelector("#titulo");
let campoTexto = document.querySelector("#campoTexto");
let btTrocarTexto = document.querySelector("#btTrocarTexto");

function alterarTexto(){
    // retirando o valor digitado no input 
    // e jogando na variavel
    let textoDigitado = campoTexto.value;
    //Atribuindo ao elemento titulo o texto digitado 
    //no input
    titulo.textContent = textoDigitado;
}

//atribuindo um ação de clicar no botao
btTrocarTexto.onclick = function(){

    alterarTexto();

}
