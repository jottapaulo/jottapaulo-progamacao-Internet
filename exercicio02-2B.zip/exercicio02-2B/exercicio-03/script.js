let imput1 = document.querySelector("#imput1");
let imput2 = document.querySelector("#imput2");
let btSomar = document.querySelector("#btSomar");
let h3ResultadoSoma = document.querySelector("#h3ResultadoSoma");
let h3ResultadoSubtracao = document.querySelector("#h3ResultadoSubtracao");
let h3ResultadoMultiplicao = document.querySelector("#h3ResultadoMultiplicao");
let h3Resultadodivisao = document.querySelector("#h3Resultadodivisao");

function exibirOperacaoes(){

    let num1 = Number(imput1.value); 
    let num2 = Number(imput2.value); 
    

    h3ResultadoSoma.textContent = " Resultado Soma: " + (num1 +  num2);
    h3ResultadoSubtracao.textContent = " Resultado Subtracao: " + (num1 -  num2);
    h3ResultadoMultiplicao.textContent = " Resultado Multiplicao: " + (num1 * num2);
    h3Resultadodivisao.textContent = " Resultado divisao: " + (num1 /  num2);
   
   
}

btSomar.onclick = function(){
    exibirOperacaoes();
}