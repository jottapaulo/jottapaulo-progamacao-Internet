let btSomar = document.querySelector("#btSomar");

let imput1 = document.querySelector("#imput1");
let imput2 = document.querySelector("#imput2");
let imput3 = document.querySelector("#imput3");
let imput4 = document.querySelector("#imput4");
let imput5 = document.querySelector("#imput5");


let h3Resultadoimput1 = document.querySelector("#h3Resultadoimput1");
let h3Resultadoimput2 = document.querySelector("#h3Resultadoimput2");
let h3Resultadoimput3 = document.querySelector("#h3Resultadoimput3");
let h3Resultadoimput4 = document.querySelector("#h3Resultadoimput4");
let h3ResultadoimputRefri = document.querySelector("#h3ResultadoimputRefri");
let h3ResultadoimputValorTotal = document.querySelector("#h3ResultadoimputValorTotal");

function exibirOperacaoes(){

    let num1 = (imput1.value); 
    let num2 = (imput2.value); 
    let num3 = (imput3.value); 
    let num4 = (imput4.value); 
    let num5 = Number(imput5.value); 
    

    h3Resultadoimput1.textContent = " Sabor 1: " + (num1);
    h3Resultadoimput2.textContent = " Sabor 2: " + (num2);
    h3Resultadoimput3.textContent = " Sabor 3: " + (num3);
    h3Resultadoimput4.textContent = " Sabor 4: " + (num4);
    h3ResultadoimputRefri.textContent = " Quantidade de Refri: " + (num5); 
    h3ResultadoimputValorTotal.textContent = " Valor Total: " + (12*4) + (num5*7);

   
   
}

btSomar.onclick = function(){
    exibirOperacaoes();
}