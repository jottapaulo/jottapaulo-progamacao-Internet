let DolarCotacao = document.querySelector("#DolarCotacao");
let btSomar = document.querySelector("#btSomar");
let h3Resultado1 = document.querySelector("#h3Resultado1");
let h3Resultado2 = document.querySelector("#h3Resultado2");
let h3Resultado5 = document.querySelector("#h3Resultado5");
let h3Resultado10 = document.querySelector("#h3Resultado10");

function calcularReajuste(){

    let num1 = Number(DolarCotacao.value); 
    

    h3Resultado1.textContent = "Soldo com reajuste 1%: " + (num1 + (num1 * (1/100)));
    h3Resultado2.textContent = "Soldo com reajuste 2%: " + (num1 + (num1 * (2/100)));
    h3Resultado5.textContent = "Soldo com reajuste 5%: " + (num1 + (num1 * (5/100)));
    h3Resultado10.textContent = "Soldo com reajuste 10%: " + (num1 + (num1 * (10/100)));
}

btSomar.onclick = function(){
    calcularReajuste();
}