let quantPessoas = document.querySelector("#quantPessoas");
let btSomar = document.querySelector("#btSomar");
let h3Resultado1 = document.querySelector("#h3Resultado1");


function calcularReajuste(){

    let num1 = Number(quantPessoas.value); 
    

    h3Resultado1.textContent = " Serao necessarios: " + (num1 * 2) + " ovos e "  +  (num1 * 50) + " gramas de queijo";
   
   
}

btSomar.onclick = function(){
    calcularReajuste();
}