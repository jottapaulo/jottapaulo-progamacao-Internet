let btCalcular = document.querySelector("#btCalcular");

let inputDias = document.querySelector("#inputDias");


let h3Resultado = document.querySelector("#h3Resultado");
let h3Resultadomeses = document.querySelector("#h3Resultadomeses");
let h3Resultadodias = document.querySelector("#h3Resultadodias");

function CalcularDias() {

let NumDias = Number (inputDias.value);



h3Resultado.textContent = "Anos sem acidentes " + (NumDias / 365 ) ;
h3Resultadomeses.textContent = "Meses sem acidentes " + (NumDias / 30 ).toFixed(0) ;
h3Resultadodias.textContent = "Dias sem acidentes " + (NumDias) ;


}

btCalcular.onclick = function(){
    CalcularDias();
}