let btSomar = document.querySelector("#btSomar");

let input1Nome = document.querySelector("#input1Nome");
let input2Idade = document.querySelector("#input2Idade");
let h3Resultado = document.querySelector ("#h3Resultado");

function CalcularDiasVividos() {

let num1 = (input1Nome.value);
let num2 = Number (input2Idade.value);

h3Resultado.textContent = (num1 + ", Voce ja viveu ") + (365 * num2) + " Dias ";


}

btSomar.onclick = function(){
    CalcularDiasVividos();
}