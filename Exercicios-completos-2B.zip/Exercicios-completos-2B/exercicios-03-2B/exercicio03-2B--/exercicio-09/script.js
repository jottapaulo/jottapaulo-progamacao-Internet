let btCalcular = document.querySelector("#btCalcular");

let inputAx = document.querySelector("#inputAx");
let inputAy = document.querySelector("#inputAy");
let inputBx = document.querySelector("#inputBx");
let inputBy = document.querySelector("#inputBy");

let h3Resultado = document.querySelector("#h3Resultado");

function CalcularX() {
    let NumAx = Number(inputAx.value);
    let NumAy = Number(inputAy.value);
    let NumBx = Number(inputBx.value);
    let NumBy = Number(inputBy.value);

    
    let distancia = Math.sqrt(Math.pow(NumBx - NumAx, 2) + Math.pow(NumBy - NumAy, 2));

    
    
    h3Resultado.textContent = "A distância entre os pontos é: " + distancia.toFixed(2);
}

btCalcular.onclick = function() {
    CalcularX();
}