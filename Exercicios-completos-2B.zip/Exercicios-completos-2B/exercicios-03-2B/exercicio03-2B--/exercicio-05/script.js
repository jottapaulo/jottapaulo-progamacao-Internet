let btCalcular = document.querySelector("#btCalcular");

let inputPreco = document.querySelector("#inputPreco");
let ValorPagamento = document.querySelector("#ValorPagamento");
let h3Resultado = document.querySelector ("#h3Resultado");

function CalcularLitros() {

let preco  = (inputPreco.value);
let pagamento = Number (ValorPagamento.value);

h3Resultado.textContent = "Ele abasteceu " + ((pagamento/preco)).toFixed(1) + "L" ;


}

btCalcular.onclick = function(){
    CalcularLitros();
}