let ValorKg = document.querySelector("#ValorKg");
let QuantKg = document.querySelector("#QuantKg");

let h3Resultado = document.querySelector("#h3Resultado");
let btcalcular = document.querySelector("#btcalcular");

function calcular(){
    let ValorKilo = Number(ValorKg.value);
    let Quantidade = Number(QuantKg.value);

    h3Resultado.textContent = "O valor total a ser pago e de R$" + (Quantidade * ValorKilo) + " Reais";
}
 btcalcular.onclick = function(){
    calcular();
 }