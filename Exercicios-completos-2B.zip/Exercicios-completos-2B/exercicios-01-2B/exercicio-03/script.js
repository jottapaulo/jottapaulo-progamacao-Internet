let Valor = document.querySelector("#Valor");
;

let h3Resultado = document.querySelector("#h3Resultado");
let btcalcular = document.querySelector("#btcalcular");

function calcular(){
    let ValorReajuste = Number(Valor.value);
    let reajuste = (ValorReajuste *1/100);

    h3Resultado.textContent = "O valor total reajustado e de R$" + (ValorReajuste + reajuste)+ "Reais";
}
 btcalcular.onclick = function(){
    calcular();
 }