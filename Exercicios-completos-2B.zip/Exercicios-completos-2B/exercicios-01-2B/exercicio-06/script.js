let imput1 = document.querySelector("#imput1");
let imput2 = document.querySelector("#imput2");
let imput3 = document.querySelector("#imput3");
let imput4= document.querySelector("#imput4");
let h3Resultado = document.querySelector("#h3Resultado");


function calcular(){

    let num1 = Number(imput1.value); 
    let num2 = Number(imput2.value); 
    let num3 = Number(imput3.value); 
    let num4 = Number(imput4.value); 
    

let menor = Math.min(num1, num2, num3, num4);
h3Resultado.textContent = "O menor valor é: " + menor;
}

btSomar.onclick = function(){
    calcular();
}