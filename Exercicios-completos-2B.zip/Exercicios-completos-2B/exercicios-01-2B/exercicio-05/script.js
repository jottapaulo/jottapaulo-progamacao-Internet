let imput1 = document.querySelector("#imput1");
let imput2 = document.querySelector("#imput2");
let h3Resultado = document.querySelector("#h3Resultado");


function calcular(){

    let num1 = Number(imput1.value); 
    let num2 = Number(imput2.value); 
    

if(num1 <= num2){
    h3Resultado.textContent = "valor 1 = " + (num1);
} else if(num2 <= num1){
    h3Resultado.textContent =  "valor 2 = " +  (num2);

}
}

btSomar.onclick = function(){
    calcular();
}