let imput1 = document.querySelector("#imput1");
let btSomar = document.querySelector("#btSomar");
let h3Resultado = document.querySelector("#h3Resultado");
function calcular(){

    let num1 = Number(imput1.value); 
    

    if(num1 % 2 !==0){
        h3Resultado.textContent = num1 + " e um numero impar";
    }else{
        h3Resultado.textContent = num1 + " e um numero par";
}
}

btSomar.onclick = function(){
    calcular();
}