let Valor = document.querySelector("#Valor");
let ValorProduto = document.querySelector("#ValorProduto");

let h3Resultado = document.querySelector("#h3Resultado");
let btcalcular = document.querySelector("#btcalcular");

function calcular(){
    let Valor1 = Number(Valor.value);
    let ValorPreco = Number(ValorProduto.value);

    h3Resultado.textContent = "O troco a ser dado e de R$" + ( Valor1 - ValorPreco )+ " Reais";
}
 btcalcular.onclick = function(){
    calcular();
 }